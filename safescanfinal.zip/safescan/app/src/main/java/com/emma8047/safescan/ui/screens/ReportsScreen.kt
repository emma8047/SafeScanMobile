package com.emma8047.safescan.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.emma8047.safescan.ScanReport
import com.emma8047.safescan.ThreatManager
import com.emma8047.safescan.ui.components.DetailRow

@Composable
fun ReportsScreen() {
    val history = ThreatManager.scanHistory.reversed() // Latest first
    var selectedReportIndex by remember { mutableStateOf<Int?>(null) }
    
    val totalScans = history.size
    val totalThreats = history.sumOf { it.threatsFound }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val reportItems = listOf(
            ReportItem("Scans Done", "$totalScans scans completed to date."),
            ReportItem("Threats Found", "$totalThreats threats have been identified."),
            ReportItem("Applications Blocked", "${ThreatManager.quarantinedApps.size} applications currently quarantined."),
            ReportItem("Average Safety Score", "${if (history.isEmpty()) 100 else history.map { it.score }.average().toInt()}% average device health.")
        )

        Column(modifier = Modifier.fillMaxWidth()) {
            reportItems.forEach { item ->
                ReportCard(item)
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
        
        if (history.isNotEmpty()) {
            Text("Recent Scan History", fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(history) { report ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F0F0))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(report.date)
                            Text("Score: ${report.score}", fontWeight = FontWeight.Bold)
                            Text("${report.threatsFound} threats", color = if (report.threatsFound > 0) Color.Red else Color.Green)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedButton(
            onClick = { 
                if (history.isNotEmpty()) {
                    selectedReportIndex = 0
                }
            },
            modifier = Modifier
                .padding(bottom = 16.dp),
            shape = RoundedCornerShape(24.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color.LightGray)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("View Past Reports", color = Color.Black)
            }
        }
    }

    selectedReportIndex?.let { index ->
        val report = history[index]
        val hasNext = index + 1 < history.size && index + 1 < 3
        
        ScanReportOverlay(
            report = report,
            onDismiss = { selectedReportIndex = null },
            onNext = if (hasNext) {
                { selectedReportIndex = index + 1 }
            } else null
        )
    }
}

data class ReportItem(val title: String, val description: String)

@Composable
fun ReportCard(item: ReportItem) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFDFDFD)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Info, // Shield-like icon
                contentDescription = null,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(text = item.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(text = item.description, fontSize = 14.sp, color = Color.Gray)
            }
        }
    }
}

@Composable
fun ScanReportOverlay(report: ScanReport, onDismiss: () -> Unit, onNext: (() -> Unit)? = null) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
        ) {
            Box(modifier = Modifier.padding(24.dp)) {
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }

                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Scan Report",
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = report.date,
                        color = Color.Gray,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = Color.Gray.copy(alpha = 0.5f), thickness = 1.dp)
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    DetailRow("Safety Score:", "${report.score}%")
                    DetailRow("Threats Found:", "${report.threatsFound}")
                    DetailRow("Apps Blocked:", "${report.appsBlocked}")
                    
                    Spacer(modifier = Modifier.height(32.dp))

                    if (onNext != null) {
                        Button(
                            onClick = onNext,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Green, contentColor = Color.Black),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("View Next Report")
                        }
                    } else {
                        Button(
                            onClick = onDismiss,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Gray),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Close", color = Color.White)
                        }
                    }
                }
            }
        }
    }
}
