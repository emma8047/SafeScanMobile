package com.emma8047.safescan

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.emma8047.safescan.ui.screens.*
import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.compose.animation.*
import kotlinx.coroutines.delay

@Composable
fun SafeScanApp() {
    val context = LocalContext.current
    var hasNotificationPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                androidx.core.content.ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
            } else true
        )
    }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { isGranted ->
            hasNotificationPermission = isGranted
        }
    )

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    var screen by remember { mutableStateOf("login") }
    var isLoggedIn by remember { mutableStateOf(false) }
    var isAdmin by remember { mutableStateOf(false) }
    var userAvatar by remember { mutableStateOf<Int?>(null) }
    var previousScreen by remember { mutableStateOf("dashboard") }
    val threatCount = ThreatManager.threatCount
    val newScanEvent = ThreatManager.newScanEvent
    var latestReport by remember { mutableStateOf<ScanReport?>(null) }
    var showRibbon by remember { mutableStateOf(false) }

    LaunchedEffect(newScanEvent) {
        if (newScanEvent != null && newScanEvent != latestReport) {
            latestReport = newScanEvent
            showRibbon = true
            delay(5000)
            showRibbon = false
            ThreatManager.newScanEvent = null // Clear event
        }
    }

    if (!isLoggedIn) {
        LoginScreen(
            onLoginSuccess = {
                isLoggedIn = true
                userAvatar = android.R.drawable.sym_def_app_icon
                FirestoreManager.loadState { admin ->
                    isAdmin = admin
                    screen = "dashboard"
                }
            }
        )
    } else {
        Scaffold(
            topBar = {
                TopBar(
                    isLoggedIn = isLoggedIn,
                    isAdmin = isAdmin,
                    userAvatar = userAvatar,
                    onProfileClick = { screen = "profile" },
                    onAdminClick = { screen = "admin" },
                    onSettingsClick = {
                        previousScreen = screen
                        screen = "settings" }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = screen == "dashboard",
                        onClick = {
                            previousScreen = screen
                            screen = "dashboard" },
                        icon = { Icon(Icons.Default.Home, "") },
                        label = { Text("Dashboard") }
                    )
                    NavigationBarItem(
                        selected = screen == "scan",
                        onClick = {
                            previousScreen = screen
                            screen = "scan" },
                        icon = { Icon(Icons.Default.Search, "") },
                        label = { Text("Scan") }
                    )
                    NavigationBarItem(
                        selected = screen == "tasks",
                        onClick = {
                            previousScreen = screen
                            screen = "tasks" },
                        icon = { Icon(Icons.Default.Menu, "") },
                        label = { Text("Task Manager") }
                    )
                    NavigationBarItem(
                        selected = screen == "quarantine",
                        onClick = {
                            previousScreen = screen
                            screen = "quarantine" },
                        icon = { Icon(Icons.Default.Lock, "") },
                        label = { Text("Quarantine") }
                    )
                    NavigationBarItem(
                        selected = screen == "reports",
                        onClick = {
                            previousScreen = screen
                            screen = "reports" },
                        icon = { Icon(Icons.Default.Info, "") },
                        label = { Text("Reports") }
                    )
                }
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                when (screen) {
                    "dashboard" -> DashboardScreen(
                        threatCount = threatCount,
                        onNavigateToScan = { screen = "scan" },
                        onNavigateToTasks = { screen = "tasks" },
                        onNavigateToReports = { screen = "reports" }
                    )
                    "scan" -> ScanScreen { apps, score ->
                        ThreatManager.updateThreats(apps, score)
                        screen = "dashboard"
                    }
                    "settings" -> SettingsScreen(
                        onBack = { screen = previousScreen },
                        onLogout = {
                            isLoggedIn = false
                            userAvatar = null
                            screen = "login"
                        }
                    )
                    "tasks" -> TaskManagerScreen()
                    "quarantine" -> QuarantineScreen()
                    "reports" -> ReportsScreen()
                    "profile" -> ProfileScreen {
                        isLoggedIn = false
                        userAvatar = null
                        screen = "login"
                    }
                    "admin" -> AdminScreen()
                }

                // Notification Ribbon
                AnimatedVisibility(
                    visible = showRibbon,
                    enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .align(Alignment.TopCenter)
                ) {
                    latestReport?.let { report ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showRibbon = false
                                    ThreatManager.markAllReportsRead()
                                },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF2E7D32)),
                            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.NotificationsActive,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        "Scan Completed",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        "Found ${report.threatsFound} threats. Score: ${report.score}%",
                                        color = Color.White.copy(alpha = 0.9f),
                                        fontSize = 12.sp
                                    )
                                }
                                Spacer(modifier = Modifier.weight(1f))
                                Icon(
                                    Icons.Default.ChevronRight,
                                    contentDescription = null,
                                    tint = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TopBar(
    isLoggedIn: Boolean,
    isAdmin: Boolean = false,
    userAvatar: Int?,
    onProfileClick: () -> Unit,
    onAdminClick: () -> Unit = {},
    onSettingsClick: () -> Unit
) {
    var showNotifications by remember { mutableStateOf(false) }

    if (showNotifications) {
        Dialog(onDismissRequest = { 
            showNotifications = false 
            ThreatManager.markAllReportsRead()
        }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .fillMaxWidth()
                        .heightIn(max = 400.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Notifications", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { 
                            showNotifications = false
                            ThreatManager.markAllReportsRead()
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    val history = ThreatManager.scanHistory
                    if (history.isEmpty()) {
                        Text("No new notifications", color = Color.Gray, fontSize = 14.sp)
                    } else {
                        Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                            history.forEach { report ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (report.isRead) Color(0xFF2A2A2A) else Color(0xFF333333)
                                    )
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (!report.isRead) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(8.dp)
                                                        .background(Color.Green, CircleShape)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                            }
                                            Text(
                                                text = "Scan Completed",
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                        }
                                        Text(
                                            text = "Found ${report.threatsFound} threats. Safety Score: ${report.score}%",
                                            color = Color.LightGray,
                                            fontSize = 12.sp
                                        )
                                        Text(
                                            text = report.date,
                                            color = Color.Gray,
                                            fontSize = 10.sp,
                                            modifier = Modifier.align(Alignment.End)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.Black)
            .statusBarsPadding()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.AccountCircle,
                contentDescription = "Profile",
                tint = Color.Gray,
                modifier = Modifier
                    .size(32.dp)
                    .clickable { onProfileClick() }
            )

            Spacer(modifier = Modifier.weight(1f))

            if (isAdmin) {
                Icon(
                    imageVector = Icons.Default.SupervisorAccount,
                    contentDescription = "Admin Panel",
                    tint = Color.Yellow,
                    modifier = Modifier
                        .size(32.dp)
                        .clickable { onAdminClick() }
                )
                Spacer(modifier = Modifier.width(16.dp))
            }

            Icon(
                imageVector = Icons.Default.Notifications,
                contentDescription = "Notifications",
                tint = Color.Gray,
                modifier = Modifier
                    .size(32.dp)
                    .clickable { showNotifications = true }
            )
            Spacer(modifier = Modifier.width(16.dp))
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "Settings",
                tint = Color.Gray,
                modifier = Modifier
                    .size(32.dp)
                    .clickable { onSettingsClick() }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "SafeScan",
            color = Color.White,
            fontSize = 48.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
