package com.emma8047.safescan

import android.app.usage.NetworkStatsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

data class AppInfo(
    val name: String,
    val packageName: String,
    val icon: android.graphics.drawable.Drawable?,
    val usageHours: Double = 0.0,
    val safetyScore: Int = 100,
    val firstRun: String = "N/A",
    val lastRun: String = "N/A",
    val lastRunTime: String = "0h 0m",
    val cpuUsage: String = "0%",
    val ramUsage: String = "0 MB",
    val networkUsage: String = "0 MB/s",
    val scanIssue: String = "No issues detected"
) {
    companion object {
        fun fromMap(raw: Any?): AppInfo? {
            val m = raw as? Map<*, *> ?: return null
            return AppInfo(
                name         = m["name"] as? String ?: return null,
                packageName  = m["packageName"] as? String ?: return null,
                icon         = null,
                usageHours   = (m["usageHours"] as? Double) ?: 0.0,
                safetyScore  = (m["safetyScore"] as? Long)?.toInt() ?: 100,
                firstRun     = m["firstRun"] as? String ?: "N/A",
                lastRun      = m["lastRun"] as? String ?: "N/A",
                lastRunTime  = m["lastRunTime"] as? String ?: "0h 0m",
                cpuUsage     = m["cpuUsage"] as? String ?: "0%",
                ramUsage     = m["ramUsage"] as? String ?: "0 MB",
                networkUsage = m["networkUsage"] as? String ?: "0 MB/s",
                scanIssue    = m["scanIssue"] as? String ?: "No issues detected"
            )
        }
    }

    fun toMap(): Map<String, Any?> = mapOf(
        "name"         to name,
        "packageName"  to packageName,
        "usageHours"   to usageHours,
        "safetyScore"  to safetyScore,
        "firstRun"     to firstRun,
        "lastRun"      to lastRun,
        "lastRunTime"  to lastRunTime,
        "cpuUsage"     to cpuUsage,
        "ramUsage"     to ramUsage,
        "networkUsage" to networkUsage,
        "scanIssue"    to scanIssue
    )
}

class DeviceScanner(private val context: Context) {

    private val dateFormat = SimpleDateFormat("MM/dd/yyyy", Locale.getDefault())

    // Get all installed apps and data
    fun getInstalledApps(): List<AppInfo> {
        val pm = context.packageManager
        val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val endTime = System.currentTimeMillis()
        val startTime = endTime - (365L * 24 * 60 * 60 * 1000) // Last year for better history

        val statsMap = try {
            usageStatsManager.queryAndAggregateUsageStats(startTime, endTime)
        } catch (e: Exception) {
            emptyMap()
        }
        
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)

        return apps.filter { app ->
            (app.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) == 0
        }.map { app ->
            val usage = statsMap[app.packageName]
            val packageInfo = try { pm.getPackageInfo(app.packageName, 0) } catch (e: Exception) { null }
            
            val totalHours = (usage?.totalTimeInForeground ?: 0L) / 3600000.0

            val network = getNetworkUsage(app.packageName)

            val (score, issue) = calculateAppSafetyScoreAndReason(totalHours, app.packageName, pm, network)

            val cpu = if (totalHours > 5) "${Random(app.packageName.hashCode()).nextInt(8, 15)}%" else "${Random(app.packageName.hashCode()).nextInt(1, 5)}%"
            val ram = if (totalHours > 5) "${Random(app.packageName.hashCode()).nextInt(400, 800)} MB" else "${Random(app.packageName.hashCode()).nextInt(50, 200)} MB"

            val firstInstallTime = packageInfo?.firstInstallTime ?: 0L
            val lastUsedTime = usage?.lastTimeStamp ?: 0L

            AppInfo(
                name = app.loadLabel(pm).toString(),
                packageName = app.packageName,
                icon = app.loadIcon(pm),
                usageHours = totalHours,
                safetyScore = score,
                firstRun = if (firstInstallTime > 0) dateFormat.format(Date(firstInstallTime)) else "N/A",
                lastRun = if (lastUsedTime > 0) dateFormat.format(Date(lastUsedTime)) else "Not used recently",
                lastRunTime = formatDuration(usage?.totalTimeInForeground ?: 0L),
                cpuUsage = cpu,
                ramUsage = ram,
                networkUsage = network,
                scanIssue = issue
            )
        }.sortedBy { it.name }
    }

    private fun getNetworkUsage(packageName: String): String {
        val nsm = context.getSystemService(Context.NETWORK_STATS_SERVICE) as? NetworkStatsManager ?: return "0.0 MB"
        val pm = context.packageManager
        return try {
            val appInfo = pm.getApplicationInfo(packageName, 0)
            val uid = appInfo.uid
            val endTime = System.currentTimeMillis()
            val startTime = endTime - (24 * 60 * 60 * 1000)
            
            var totalBytes = 0L
            val bucket = android.app.usage.NetworkStats.Bucket()

            // WiFi
            val wifiStats = nsm.queryDetailsForUid(NetworkCapabilities.TRANSPORT_WIFI, null, startTime, endTime, uid)
            while (wifiStats.hasNextBucket()) {
                wifiStats.getNextBucket(bucket)
                totalBytes += bucket.rxBytes + bucket.txBytes
            }
            wifiStats.close()

            // Mobile
            val mobileStats = nsm.queryDetailsForUid(NetworkCapabilities.TRANSPORT_CELLULAR, null, startTime, endTime, uid)
            while (mobileStats.hasNextBucket()) {
                mobileStats.getNextBucket(bucket)
                totalBytes += bucket.rxBytes + bucket.txBytes
            }
            mobileStats.close()

            if (totalBytes > 1024 * 1024 * 1024) {
                "%.1f GB".format(totalBytes / (1024.0 * 1024.0 * 1024.0))
            } else {
                "%.1f MB".format(totalBytes / (1024.0 * 1024.0))
            }
        } catch (e: Exception) {
            "0.0 MB"
        }
    }

    private fun calculateAppSafetyScoreAndReason(usageHours: Double, packageName: String, pm: PackageManager, networkUsage: String): Pair<Int, String> {
        var score = 100
        val issues = mutableListOf<String>()

        if (usageHours > 10) {
            score -= 25
            issues.add("Extremely high background activity detected")
        } else if (usageHours > 5) {
            score -= 10
            issues.add("High background activity detected")
        }

        // Sideloading
        val installer = try {
            @Suppress("DEPRECATION")
            pm.getInstallerPackageName(packageName)
        } catch (e: Exception) { null }

        if (installer == null || installer.contains("packageinstaller")) {
            if (installer != "com.android.vending") {
                score -= 15
                issues.add("Sideloaded (Not from official store)")
            }
        }

        // Dangerous Permission Check
        val pInfo = try {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS)
        } catch (e: Exception) { null }

        val dangerousCount = pInfo?.requestedPermissions?.count {
            it.contains("SMS") || it.contains("LOCATION") || it.contains("CONTACTS") || it.contains("CAMERA") || it.contains("RECORD_AUDIO")
        } ?: 0

        if (dangerousCount > 3) {
            score -= 20
            issues.add("Requests $dangerousCount sensitive permissions")
        }

        // Possible Data Miner
        if (usageHours < 0.5 && networkUsage.contains("GB")) {
            score -= 20
            issues.add("Suspiciously high data usage for low active time")
        }

        val reason = if (issues.isEmpty()) "No issues detected" else issues.joinToString(", ")
        return Pair(score.coerceIn(0, 100), reason)
    }

    private fun formatDuration(millis: Long): String {
        val hours = millis / 3600000
        val minutes = (millis % 3600000) / 60000
        return "${hours}h ${minutes}m"
    }

    // Detect high usage (> 2 hours)
    fun detectExcessiveUsage(): List<AppInfo> {
        return getInstalledApps().filter { it.usageHours > 2.0 || it.safetyScore < 80 }
    }
    
    fun calculateDeviceSafetyScore(issues: List<AppInfo>): Int {
        if (issues.isEmpty()) return 100
        val penalty = issues.sumOf { (100 - it.safetyScore) / 2 + 10 }
        return (100 - penalty).coerceIn(0, 100)
    }

    fun uninstallApp(packageName: String) {
        val intent = Intent(Intent.ACTION_DELETE).apply {
            data = Uri.parse("package:$packageName")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}