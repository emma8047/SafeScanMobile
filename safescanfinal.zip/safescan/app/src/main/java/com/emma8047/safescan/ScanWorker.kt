package com.emma8047.safescan

import android.content.Context
import android.os.Build
import androidx.work.*
import java.util.*
import java.util.concurrent.TimeUnit
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

class ScanWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    override fun doWork(): Result {
        val scanner = DeviceScanner(applicationContext)
        val threats = scanner.detectExcessiveUsage()
        val score = scanner.calculateDeviceSafetyScore(threats)

        ThreatManager.updateThreats(threats, score)
        
        sendScanNotification(threats.size, score)
        
        return Result.success()
    }

    private fun sendScanNotification(threatCount: Int, score: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                return
            }
        }

        val builder = NotificationCompat.Builder(applicationContext, SafeScanApplication.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Scan Completed")
            .setContentText("Found $threatCount threats. Device Safety Score: $score%")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)

        with(NotificationManagerCompat.from(applicationContext)) {
            notify(NOTIFICATION_ID, builder.build())
        }
    }

    companion object {
        private const val WORK_NAME = "WeeklyScanWork"
        private const val NOTIFICATION_ID = 1

        fun scheduleWeeklyScan(context: Context, hour: Int, minute: Int) {
            val constraints = Constraints.Builder()
                .setRequiresBatteryNotLow(true)
                .build()

            val initialDelay = calculateInitialDelay(hour, minute)

            val workRequest = PeriodicWorkRequestBuilder<ScanWorker>(7, TimeUnit.DAYS)
                .setConstraints(constraints)
                .setInitialDelay(initialDelay, TimeUnit.MILLISECONDS)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                workRequest
            )
        }

        private fun calculateInitialDelay(hour: Int, minute: Int): Long {
            val calendar = Calendar.getInstance()
            val now = calendar.timeInMillis

            calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY)
            calendar.set(Calendar.HOUR_OF_DAY, hour)
            calendar.set(Calendar.MINUTE, minute)
            calendar.set(Calendar.SECOND, 0)
            calendar.set(Calendar.MILLISECOND, 0)

            if (calendar.timeInMillis <= now) {
                calendar.add(Calendar.WEEK_OF_YEAR, 1)
            }

            return calendar.timeInMillis - now
        }
        fun cancelWeeklyScan(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
