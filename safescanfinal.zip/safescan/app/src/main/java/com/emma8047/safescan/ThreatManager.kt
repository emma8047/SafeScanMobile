package com.emma8047.safescan

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.text.SimpleDateFormat
import java.util.*

data class ScanReport(
    val id: String = UUID.randomUUID().toString(),
    val date: String,
    val score: Int,
    val threatsFound: Int,
    val appsBlocked: Int,
    val isRead: Boolean = false
)

object ThreatManager {
    var deviceScore by mutableStateOf(100)
    var threatCount by mutableStateOf(0)
    
    var activeThreats by mutableStateOf<List<AppInfo>>(emptyList())
    var latestIncidents by mutableStateOf<List<AppInfo>>(emptyList())
    var quarantinedApps by mutableStateOf<List<AppInfo>>(emptyList())
    var scanHistory by mutableStateOf<List<ScanReport>>(emptyList())
    
    // Event to trigger the UI ribbon only on fresh scans
    var newScanEvent by mutableStateOf<ScanReport?>(null)

    fun updateThreats(apps: List<AppInfo>, score: Int) {
        activeThreats = apps
        latestIncidents = apps
        deviceScore = score
        threatCount = apps.size
        
        val report = ScanReport(
            id = UUID.randomUUID().toString(),
            date = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()).format(Date()),
            score = score,
            threatsFound = apps.size,
            appsBlocked = quarantinedApps.size,
            isRead = false
        )
        scanHistory = listOf(report) + scanHistory
        newScanEvent = report
        FirestoreManager.saveState()
    }

    fun markAllReportsRead() {
        scanHistory = scanHistory.map { it.copy(isRead = true) }
        FirestoreManager.saveState()
    }

    fun quarantineApp(app: AppInfo) {
        if (!quarantinedApps.any { it.packageName == app.packageName }) {
            quarantinedApps = quarantinedApps + app

            FirestoreManager.saveState()
        }
    }

    fun ignoreApp(app: AppInfo) {
        latestIncidents = latestIncidents.filter { it.packageName != app.packageName }
        FirestoreManager.saveState()
    }

    fun restoreApp(app: AppInfo) {
        quarantinedApps = quarantinedApps.filter { it.packageName != app.packageName }
        
        // When restored from quarantine, remove from active threats
        activeThreats = activeThreats.filter { it.packageName != app.packageName }
        latestIncidents = latestIncidents.filter { it.packageName != app.packageName }
        threatCount = activeThreats.size

        recalculateScore()
        FirestoreManager.saveState()
    }

    fun deleteApp(packageName: String) {
        activeThreats = activeThreats.filter { it.packageName != packageName }
        latestIncidents = latestIncidents.filter { it.packageName != packageName }
        quarantinedApps = quarantinedApps.filter { it.packageName != packageName }
        threatCount = activeThreats.size

        recalculateScore()
        FirestoreManager.saveState()
    }

    private fun recalculateScore() {
        if (activeThreats.isEmpty()) {
            deviceScore = 100
        } else {
            val penalty = activeThreats.sumOf { (100 - it.safetyScore) / 2 + 10 }
            deviceScore = (100 - penalty).coerceIn(0, 100)
        }
    }
}
