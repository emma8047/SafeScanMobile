package com.emma8047.safescan.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.clickable
import com.emma8047.safescan.AppInfo
import com.emma8047.safescan.DeviceScanner
import com.emma8047.safescan.ThreatManager
import com.emma8047.safescan.ui.components.AppDetailOverlay
import com.emma8047.safescan.ui.components.AppIncidentCard
import com.emma8047.safescan.ui.components.DashboardButton

@Composable
fun DashboardScreen(
    threatCount: Int,
    onNavigateToScan: () -> Unit,
    onNavigateToTasks: () -> Unit,
    onNavigateToReports: () -> Unit
) {
    val deviceScore = ThreatManager.deviceScore
    val color = if (deviceScore >= 100) Color.Green else if (deviceScore >= 80) Color.Yellow else if (deviceScore >= 50) Color(0xFFFFA500) else Color.Red
    val text = if (deviceScore >= 100) "100% SECURE" else "${ThreatManager.activeThreats.size} THREATS"
    val subText = if (deviceScore >= 100) "Your Device is Safe!" else "Security Risk Detected!"

    var selectedApp by remember { mutableStateOf<AppInfo?>(null) }
    var viewingReportForApp by remember { mutableStateOf<AppInfo?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Spacer(Modifier.height(24.dp))

            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(220.dp)) {
                    drawArc(
                        color = Color.Gray.copy(alpha = 0.2f),
                        startAngle = 0f,
                        sweepAngle = 360f,
                        useCenter = false,
                        style = Stroke(40f)
                    )
                    drawArc(
                        color = color,
                        startAngle = -90f,
                        sweepAngle = (deviceScore / 100f) * 360f,
                        useCenter = false,
                        style = Stroke(40f)
                    )
                }

                Text(
                    text = text,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = color,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(Modifier.height(16.dp))
            Text(subText, fontSize = 14.sp, color = Color.Gray)
            Spacer(Modifier.height(32.dp))

            DashboardButton("INVESTIGATE") { onNavigateToScan() }
            Spacer(Modifier.height(12.dp))
            DashboardButton("VIEW TASK MANAGER") { onNavigateToTasks() }
            Spacer(Modifier.height(12.dp))
            DashboardButton("LAST REPORT") { onNavigateToReports() }

            Spacer(Modifier.height(32.dp))

            Row(Modifier.fillMaxWidth()) {
                Text(
                    text = "Incidents",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Spacer(Modifier.height(16.dp))
        }

        if (ThreatManager.latestIncidents.isEmpty()) {
            item {
                Text(
                    text = "No recent incidents found.",
                    color = Color.Gray,
                    modifier = Modifier.padding(vertical = 16.dp)
                )
            }
        } else {
            items(ThreatManager.latestIncidents) { app ->
                AppIncidentCard(app) {
                    selectedApp = app
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    selectedApp?.let { app ->
        val context = LocalContext.current
        val scanner = remember { DeviceScanner(context) }
        IncidentOverlay(
            app = app,
            onDismiss = { selectedApp = null },
            onDelete = { scanner.uninstallApp(app.packageName) },
            onViewReport = { 
                viewingReportForApp = app
                selectedApp = null
            }
        )
    }

    viewingReportForApp?.let { app ->
        AppDetailOverlay(app = app, onDismiss = { viewingReportForApp = null })
    }
}

@Composable
fun IncidentOverlay(app: AppInfo, onDismiss: () -> Unit, onDelete: () -> Unit, onViewReport: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
        ) {
            Box(modifier = Modifier.padding(24.dp)) {
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = app.name,
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(top = 8.dp)
                    )

                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 16.dp),
                        color = Color.Gray.copy(alpha = 0.5f)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        OverlayOption(Icons.Default.Warning, "IGNORE", Color.Green) { 
                            ThreatManager.ignoreApp(app)
                            onDismiss()
                        }
                        OverlayOption(Icons.Default.Menu, "QUARANTINE", Color(0xFFFFA500)) { 
                            ThreatManager.quarantineApp(app)
                            onDismiss()
                        }
                        OverlayOption(Icons.Default.Delete, "DELETE", Color.Red) {
                            onDelete()
                            ThreatManager.deleteApp(app.packageName)
                            onDismiss()
                        }
                    }

                    Spacer(modifier = Modifier.height(32.dp))

                    OutlinedButton(
                        onClick = onViewReport,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(25.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White)
                    ) {
                        Text("VIEW REPORT", color = Color.White, letterSpacing = 1.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun OverlayOption(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, color: Color, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = color,
            modifier = Modifier.size(36.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = label,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
