package com.emma8047.safescan.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.emma8047.safescan.*
import com.emma8047.safescan.ui.components.ExtraBoldText
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

@Composable
fun ScanScreen(onScanComplete: (List<AppInfo>, Int) -> Unit) {
    val context = LocalContext.current
    val scanner = remember { DeviceScanner(context) }
    var isScanning by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var showResults by remember { mutableStateOf(false) }
    var scanResults by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var deviceScore by remember { mutableIntStateOf(100) }

    LaunchedEffect(isScanning) {
        if (isScanning) {
            progress = 0f
            while (progress < 1f) {
                kotlinx.coroutines.delay(30)
                progress += 0.05f
            }
            // Use the real scanning logic from DeviceScanner
            scanResults = try {
                scanner.detectExcessiveUsage()
            } catch (_: Exception) {
                emptyList()
            }
            deviceScore = scanner.calculateDeviceSafetyScore(scanResults)
            isScanning = false
            showResults = true
            sendManualScanNotification(context, scanResults.size, deviceScore)
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        if (!isScanning && !showResults) {
            Button(
                onClick = { isScanning = true },
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .fillMaxHeight(0.4f),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Green),
                shape = RoundedCornerShape(32.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.Black)
            ) {
                Text(
                    text = "SYSTEM CHECK",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(
                    progress = { if (showResults) 1f else progress },
                    modifier = Modifier.size(150.dp),
                    color = Color.Green,
                    strokeWidth = 12.dp,
                )
                Spacer(Modifier.height(32.dp))
                Text(
                    text = if (showResults) "SCAN COMPLETE" else "SCANNING... ${(progress * 100).toInt()}%",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        if (showResults) {
            ScanResultOverlay(
                results = scanResults,
                score = deviceScore,
                onDismiss = {
                    showResults = false
                    onScanComplete(scanResults, deviceScore)
                }
            )
        }
    }
}

private fun sendManualScanNotification(context: android.content.Context, threatCount: Int, score: Int) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return
        }
    }

    val builder = NotificationCompat.Builder(context, SafeScanApplication.CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_dialog_info)
        .setContentTitle("Manual Scan Completed")
        .setContentText("Found $threatCount threats. Device Safety Score: $score%")
        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
        .setAutoCancel(true)

    try {
        with(NotificationManagerCompat.from(context)) {
            notify(2, builder.build())
        }
    } catch (_: SecurityException) {
    }
}

@Composable
fun ScanResultOverlay(results: List<AppInfo>, score: Int, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        ExtraBoldText("Scan Complete", 28.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Safety Score: ",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "$score/100",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = if (score > 80) Color(0xFF2E7D32) else if (score > 50) Color(0xFFF57C00) else Color.Red
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            modifier = Modifier.size(32.dp),
                            tint = Color.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (results.isEmpty()) {
                    Text("Your device is currently optimized and secure.", color = Color.Gray)
                } else {
                    Text("Issues Detected:", fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))
                    results.forEach { app ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(Color(0xFFF2F4F7), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = Color.Red,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(app.name, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Safety Score: ${app.safetyScore}%",
                                    color = Color.Gray,
                                    fontSize = 14.sp
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF2F4F7)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Root Cause:", fontWeight = FontWeight.Bold)
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), thickness = 0.5.dp)
                        val summaryText = if (results.isEmpty()) {
                            "All systems normal."
                        } else {
                            results.joinToString("\n• ", prefix = "• ") { "${it.name}: ${it.scanIssue}" }
                        }
                        Text(
                            text = summaryText,
                            color = Color.Gray,
                            fontSize = 14.sp
                        )
                    }
                }

                if (results.isNotEmpty()) {
                    val context = LocalContext.current
                    val scanner = remember { DeviceScanner(context) }
                    
                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = { 
                            results.forEach { ThreatManager.quarantineApp(it) }
                            onDismiss()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE67E00)),
                        shape = RoundedCornerShape(25.dp)
                    ) {
                        Text("Quarantine All", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { 
                            results.forEach { 
                                scanner.uninstallApp(it.packageName)
                                ThreatManager.deleteApp(it.packageName)
                            }
                            onDismiss()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                        shape = RoundedCornerShape(25.dp)
                    ) {
                        Text("Uninstall Threats", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
