package com.emma8047.safescan.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import android.widget.Toast
import com.emma8047.safescan.FirestoreManager

@Composable
fun AdminScreen() {
    var stats by remember { mutableStateOf<Map<String, Any>?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    
    var showUserIds by remember { mutableStateOf(false) }
    var showFlaggedApps by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        FirestoreManager.fetchGlobalStats { fetchedStats ->
            if (fetchedStats != null) {
                stats = fetchedStats
            } else {
                errorMessage = "Failed to load analytics. Please check permissions."
            }
            isLoading = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Global Usage Analytics",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black
        )
        Spacer(modifier = Modifier.height(32.dp))

        if (isLoading) {
            CircularProgressIndicator(color = Color.Green)
        } else if (errorMessage != null) {
            Text(
                text = errorMessage!!,
                color = Color.Red,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(16.dp)
            )
        } else {
            stats?.let {
                val totalUsers = it["totalUsers"] as? Int ?: 0
                val totalThreats = it["totalThreats"] as? Int ?: 0
                val totalScans = it["totalScans"] as? Int ?: 0
                
                val avgThreats = if (totalScans > 0) String.format("%.2f", totalThreats.toFloat() / totalScans) else "0.00"

                AdminStatCard(
                    title = "Total Users", 
                    value = totalUsers.toString(), 
                    icon = Icons.Default.Person,
                    actionText = "Show IDs",
                    onAction = { showUserIds = true }
                )
                Spacer(modifier = Modifier.height(16.dp))
                
                AdminStatCard(
                    title = "Total Threats Detected", 
                    value = totalThreats.toString(), 
                    icon = Icons.Default.Warning,
                    actionText = "Show Apps",
                    onAction = { showFlaggedApps = true }
                )
                Spacer(modifier = Modifier.height(16.dp))
                
                AdminStatCard("Total Scans Performed", totalScans.toString(), Icons.Default.Search)
                Spacer(modifier = Modifier.height(16.dp))
                
                AdminStatCard("Avg Threats Per Scan", avgThreats, Icons.Default.Assessment)
                
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    if (showUserIds) {
        val ids = stats?.get("userIds") as? List<String> ?: emptyList()
        AdminListDialog(
            title = "User IDs", 
            items = ids, 
            onDismiss = { showUserIds = false },
            onDeleteUser = { uid ->
                FirestoreManager.adminDeleteUser(uid) { success ->
                    if (success) {
                        FirestoreManager.fetchGlobalStats { fetchedStats ->
                            stats = fetchedStats
                        }
                    }
                }
            }
        )
    }

    if (showFlaggedApps) {
        val apps = stats?.get("flaggedApps") as? List<String> ?: emptyList()
        AdminListDialog("Flagged Threat Apps", apps, onDismiss = { showFlaggedApps = false })
    }
}

@Composable
fun AdminListDialog(
    title: String, 
    items: List<String>, 
    onDismiss: () -> Unit,
    onDeleteUser: ((String) -> Unit)? = null
) {
    val context = LocalContext.current
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth().heightIn(max = 400.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(items) { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(item, modifier = Modifier.weight(1f))
                            if (onDeleteUser != null) {
                                IconButton(onClick = {
                                    onDeleteUser(item)
                                    Toast.makeText(context, "User data deleted", Toast.LENGTH_SHORT).show()
                                }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete User", tint = Color.Red)
                                }
                            }
                        }
                        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
                    }
                }
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) {
                    Text("Close")
                }
            }
        }
    }
}

@Composable
fun AdminStatCard(
    title: String, 
    value: String, 
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    actionText: String? = null,
    onAction: (() -> Unit)? = null
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF2F4F7))
    ) {
        Row(
            modifier = Modifier.padding(24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.Black,
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.width(20.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontSize = 14.sp, color = Color.Gray)
                Text(text = value, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Color.Black)
            }
            if (actionText != null && onAction != null) {
                TextButton(onClick = onAction) {
                    Text(actionText, color = Color.Blue)
                }
            }
        }
    }
}
