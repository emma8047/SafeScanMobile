package com.emma8047.safescan

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.emma8047.safescan.ui.screens.*
import com.google.firebase.auth.FirebaseAuth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.window.Dialog

@Composable
fun SafeScanApp() {
    var screen by remember { mutableStateOf("login") }
    var isLoggedIn by remember { mutableStateOf(false) }
    var isAdmin by remember { mutableStateOf(false) }
    var userAvatar by remember { mutableStateOf<Int?>(null) }
    var previousScreen by remember { mutableStateOf("dashboard") }
    val threatCount = ThreatManager.threatCount

    if (!isLoggedIn) {
        LoginScreen(
            onLoginSuccess = {
                isLoggedIn = true
                userAvatar = android.R.drawable.sym_def_app_icon
                FirestoreManager.loadState { admin ->
                    isAdmin = admin
                    screen = "dashboard"
                }
            }
        )
    } else {
        Scaffold(
            topBar = {
                TopBar(
                    isLoggedIn = isLoggedIn,
                    isAdmin = isAdmin,
                    userAvatar = userAvatar,
                    onProfileClick = { screen = "profile" },
                    onAdminClick = { screen = "admin" },
                    onSettingsClick = {
                        previousScreen = screen
                        screen = "settings" }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = screen == "dashboard",
                        onClick = {
                            previousScreen = screen
                            screen = "dashboard" },
                        icon = { Icon(Icons.Default.Home, "") },
                        label = { Text("Dashboard") }
                    )
                    NavigationBarItem(
                        selected = screen == "scan",
                        onClick = {
                            previousScreen = screen
                            screen = "scan" },
                        icon = { Icon(Icons.Default.Search, "") },
                        label = { Text("Scan") }
                    )
                    NavigationBarItem(
                        selected = screen == "tasks",
                        onClick = {
                            previousScreen = screen
                            screen = "tasks" },
                        icon = { Icon(Icons.Default.Menu, "") },
                        label = { Text("Task Manager") }
                    )
                    NavigationBarItem(
                        selected = screen == "quarantine",
                        onClick = {
                            previousScreen = screen
                            screen = "quarantine" },
                        icon = { Icon(Icons.Default.Lock, "") },
                        label = { Text("Quarantine") }
                    )
                    NavigationBarItem(
                        selected = screen == "reports",
                        onClick = {
                            previousScreen = screen
                            screen = "reports" },
                        icon = { Icon(Icons.Default.Info, "") },
                        label = { Text("Reports") }
                    )
                }
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                when (screen) {
                    "dashboard" -> DashboardScreen(
                        threatCount = threatCount,
                        onNavigateToScan = { screen = "scan" },
                        onNavigateToTasks = { screen = "tasks" },
                        onNavigateToReports = { screen = "reports" }
                    )
                    "scan" -> ScanScreen { apps, score ->
                        ThreatManager.updateThreats(apps, score)
                        screen = "dashboard"
                    }
                    "settings" -> SettingsScreen(
                        onBack = { screen = previousScreen },
                        onLogout = {
                            isLoggedIn = false
                            userAvatar = null
                            screen = "login"
                        }
                    )
                    "tasks" -> TaskManagerScreen()
                    "quarantine" -> QuarantineScreen()
                    "reports" -> ReportsScreen()
                    "profile" -> ProfileScreen {
                        isLoggedIn = false
                        userAvatar = null
                        screen = "login"
                    }
                    "admin" -> AdminScreen()
                }
            }
        }
    }
}

@Composable
fun TopBar(
    isLoggedIn: Boolean,
    isAdmin: Boolean = false,
    userAvatar: Int?,
    onProfileClick: () -> Unit,
    onAdminClick: () -> Unit = {},
    onSettingsClick: () -> Unit
) {
    var showNotifications by remember { mutableStateOf(false) }

    if (showNotifications) {
        Dialog(onDismissRequest = { showNotifications = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Notifications", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { showNotifications = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("No new notifications", color = Color.Gray, fontSize = 14.sp)
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.Black)
            .statusBarsPadding()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.AccountCircle,
                contentDescription = "Profile",
                tint = Color.Gray,
                modifier = Modifier
                    .size(32.dp)
                    .clickable { onProfileClick() }
            )

            Spacer(modifier = Modifier.weight(1f))

            if (isAdmin) {
                Icon(
                    imageVector = Icons.Default.SupervisorAccount,
                    contentDescription = "Admin Panel",
                    tint = Color.Yellow,
                    modifier = Modifier
                        .size(32.dp)
                        .clickable { onAdminClick() }
                )
                Spacer(modifier = Modifier.width(16.dp))
            }

            Icon(
                imageVector = Icons.Default.Notifications,
                contentDescription = "Notifications",
                tint = Color.Gray,
                modifier = Modifier
                    .size(32.dp)
                    .clickable { showNotifications = true }
            )
            Spacer(modifier = Modifier.width(16.dp))
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "Settings",
                tint = Color.Gray,
                modifier = Modifier
                    .size(32.dp)
                    .clickable { onSettingsClick() }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "SafeScan",
            color = Color.White,
            fontSize = 48.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
