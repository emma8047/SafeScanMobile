package com.emma8047.safescan

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions

object FirestoreManager {

    private val db = FirebaseFirestore.getInstance()

    private fun uid(): String? = FirebaseAuth.getInstance().currentUser?.uid

    fun saveState() {
        val uid = uid() ?: return

        val active = ThreatManager.activeThreats.map { it.toMap() }
        val latest = ThreatManager.latestIncidents.map { it.toMap() }
        val quarantined = ThreatManager.quarantinedApps.map { it.toMap() }
        val history = ThreatManager.scanHistory.map {
            mapOf("date" to it.date, "score" to it.score,
                "threatsFound" to it.threatsFound, "appsBlocked" to it.appsBlocked)
        }

        val data = mapOf(
            "deviceScore"      to ThreatManager.deviceScore,
            "threatCount"      to ThreatManager.threatCount,
            "activeThreats"    to active,
            "latestIncidents"  to latest,
            "quarantinedApps"  to quarantined,
            "scanHistory"      to history
        )

        db.collection("users").document(uid)
            .set(data, SetOptions.merge())
    }

    fun loadState(onComplete: (isAdmin: Boolean) -> Unit = {}) {
        val uid = uid() ?: run { onComplete(false); return }

        db.collection("users").document(uid).get()
            .addOnSuccessListener { doc ->
                var isAdmin = false
                if (doc.exists()) {
                    isAdmin = doc.getBoolean("isAdmin") ?: false
                    ThreatManager.deviceScore =
                        (doc.getLong("deviceScore") ?: 100L).toInt()
                    ThreatManager.threatCount =
                        (doc.getLong("threatCount") ?: 0L).toInt()

                    ThreatManager.activeThreats =
                        (doc.get("activeThreats") as? List<*>)
                            ?.mapNotNull { AppInfo.fromMap(it) } ?: emptyList()

                    ThreatManager.latestIncidents =
                        (doc.get("latestIncidents") as? List<*>)
                            ?.mapNotNull { AppInfo.fromMap(it) } ?: emptyList()

                    ThreatManager.quarantinedApps =
                        (doc.get("quarantinedApps") as? List<*>)
                            ?.mapNotNull { AppInfo.fromMap(it) } ?: emptyList()

                    ThreatManager.scanHistory =
                        (doc.get("scanHistory") as? List<*>)
                            ?.mapNotNull { entry ->
                                val m = entry as? Map<*, *> ?: return@mapNotNull null
                                ScanReport(
                                    date        = m["date"] as? String ?: "",
                                    score       = (m["score"] as? Long)?.toInt() ?: 100,
                                    threatsFound= (m["threatsFound"] as? Long)?.toInt() ?: 0,
                                    appsBlocked = (m["appsBlocked"] as? Long)?.toInt() ?: 0
                                )
                            } ?: emptyList()
                }
                onComplete(isAdmin)
            }
            .addOnFailureListener { onComplete(false) }
    }

    fun fetchGlobalStats(onComplete: (Map<String, Any>?) -> Unit) {
        db.collection("users").get()
            .addOnSuccessListener { query ->
                val totalUsers = query.size()
                var totalThreats = 0
                var totalScans = 0
                val userIds = mutableListOf<String>()
                val flaggedApps = mutableSetOf<String>()
                
                for (doc in query) {
                    userIds.add(doc.id)
                    totalThreats += (doc.getLong("threatCount") ?: 0).toInt()
                    
                    val history = doc.get("scanHistory") as? List<*>
                    totalScans += history?.size ?: 0
                    
                    val incidents = doc.get("latestIncidents") as? List<*>
                    incidents?.forEach { 
                        val m = it as? Map<*, *>
                        val appName = m?.get("name") as? String
                        if (appName != null) flaggedApps.add(appName)
                    }
                }

                onComplete(mapOf(
                    "totalUsers" to totalUsers,
                    "totalThreats" to totalThreats,
                    "totalScans" to totalScans,
                    "userIds" to userIds,
                    "flaggedApps" to flaggedApps.toList()
                ))
            }
            .addOnFailureListener {
                onComplete(null)
            }
    }

    fun getAdminStats(callback: (Map<String, Any>) -> Unit) {
        db.collection("admin").document("stats").get().addOnSuccessListener { doc ->
            callback(doc.data ?: emptyMap())
        }
    }
}
