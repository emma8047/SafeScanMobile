package com.emma8047.safescan.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.emma8047.safescan.AppInfo
import com.emma8047.safescan.DeviceScanner
import com.emma8047.safescan.ThreatManager
import com.emma8047.safescan.ui.components.AppDetailOverlay

@Composable
fun QuarantineScreen() {
    var selectedApp by remember { mutableStateOf<AppInfo?>(null) }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Search Bar
        OutlinedTextField(
            value = "",
            onValueChange = {},
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            placeholder = { Text("App Name") },
            leadingIcon = { Icon(Icons.Default.Menu, contentDescription = null) },
            trailingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFFF0F0F0),
                unfocusedContainerColor = Color(0xFFF0F0F0),
                unfocusedBorderColor = Color.Transparent,
                focusedBorderColor = Color.Transparent
            )
        )

        val quarantinedApps = ThreatManager.quarantinedApps

        val context = LocalContext.current
        val scanner = remember { DeviceScanner(context) }

        if (quarantinedApps.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No apps in quarantine.", color = Color.Gray)
            }
        } else {
            LazyColumn {
                items(quarantinedApps) { app ->
                    QuarantineCard(
                        app = app,
                        onUninstall = { 
                            scanner.uninstallApp(app.packageName)
                            ThreatManager.deleteApp(app.packageName)
                        },
                        onRestore = {
                            ThreatManager.restoreApp(app)
                        },
                        onReviewEvidence = {
                            selectedApp = app
                        }
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }

    selectedApp?.let { app ->
        AppDetailOverlay(app = app, onDismiss = { selectedApp = null })
    }
}

@Composable
fun QuarantineCard(app: AppInfo, onUninstall: () -> Unit, onRestore: () -> Unit, onReviewEvidence: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8F8F8)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = Color.Red,
                    modifier = Modifier.size(32.dp)
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(text = app.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(text = "Safety Score: ${app.safetyScore}%", fontSize = 12.sp, color = Color.Gray)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                QuarantineButton("Restore") { onRestore() }
                QuarantineButton("Uninstall") { onUninstall() }
                QuarantineButton("Review Evidence") { onReviewEvidence() }
            }
        }
    }
}

@Composable
fun QuarantineButton(text: String, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
        modifier = Modifier.height(32.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.Gray)
    ) {
        Text(text = text, fontSize = 10.sp, color = Color.Black)
    }
}
