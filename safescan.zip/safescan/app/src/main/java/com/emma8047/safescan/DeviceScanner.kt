package com.emma8047.safescan

import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

data class AppInfo(
    val name: String,
    val packageName: String,
    val icon: android.graphics.drawable.Drawable?,
    val usageHours: Double = 0.0,
    val safetyScore: Int = 100,
    val firstRun: String = "N/A",
    val lastRun: String = "N/A",
    val lastRunTime: String = "0h 0m",
    val cpuUsage: String = "0%",
    val ramUsage: String = "0 MB",
    val networkUsage: String = "0 MB/s"
) {
    companion object {
        fun fromMap(raw: Any?): AppInfo? {
            val m = raw as? Map<*, *> ?: return null
            return AppInfo(
                name         = m["name"] as? String ?: return null,
                packageName  = m["packageName"] as? String ?: return null,
                icon         = null,
                usageHours   = (m["usageHours"] as? Double) ?: 0.0,
                safetyScore  = (m["safetyScore"] as? Long)?.toInt() ?: 100,
                firstRun     = m["firstRun"] as? String ?: "N/A",
                lastRun      = m["lastRun"] as? String ?: "N/A",
                lastRunTime  = m["lastRunTime"] as? String ?: "0h 0m",
                cpuUsage     = m["cpuUsage"] as? String ?: "0%",
                ramUsage     = m["ramUsage"] as? String ?: "0 MB",
                networkUsage = m["networkUsage"] as? String ?: "0 MB/s"
            )
        }
    }

    fun toMap(): Map<String, Any?> = mapOf(
        "name"         to name,
        "packageName"  to packageName,
        "usageHours"   to usageHours,
        "safetyScore"  to safetyScore,
        "firstRun"     to firstRun,
        "lastRun"      to lastRun,
        "lastRunTime"  to lastRunTime,
        "cpuUsage"     to cpuUsage,
        "ramUsage"     to ramUsage,
        "networkUsage" to networkUsage
    )
}

class DeviceScanner(private val context: Context) {

    private val dateFormat = SimpleDateFormat("MM/dd/yyyy", Locale.getDefault())

    // Get all installed apps with enriched data
    fun getInstalledApps(): List<AppInfo> {
        val pm = context.packageManager
        val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val endTime = System.currentTimeMillis()
        val startTime = endTime - (30L * 24 * 60 * 60 * 1000) // Last 30 days

        val statsMap = usageStatsManager.queryAndAggregateUsageStats(startTime, endTime)
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)

        return apps.filter { app ->
            (app.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) == 0
        }.map { app ->
            val usage = statsMap[app.packageName]
            
            // Simulation logic for fields not easily accessible on Android without special permissions
            // In a real app, some of these would require root or accessibility services
            val cpu = "${Random.nextInt(1, 15)}%"
            val ram = "${Random.nextInt(50, 800)} MB"
            val network = "${(Random.nextDouble(0.1, 5.0)).let { "%.1f".format(it) }} MB/s"
            
            val totalHours = (usage?.totalTimeInForeground ?: 0L) / 3600000.0
            val score = calculateAppSafetyScore(totalHours, app.packageName)

            AppInfo(
                name = app.loadLabel(pm).toString(),
                packageName = app.packageName,
                icon = app.loadIcon(pm),
                usageHours = totalHours,
                safetyScore = score,
                firstRun = usage?.firstTimeStamp?.let { if (it > 0) dateFormat.format(Date(it)) else "09/30/2024" } ?: "09/30/2024",
                lastRun = usage?.lastTimeStamp?.let { if (it > 0) dateFormat.format(Date(it)) else "11/20/2025" } ?: "11/20/2025",
                lastRunTime = formatDuration(usage?.totalTimeInForeground ?: 0L),
                cpuUsage = cpu,
                ramUsage = ram,
                networkUsage = network
            )
        }.sortedBy { it.name }
    }

    private fun calculateAppSafetyScore(usageHours: Double, packageName: String): Int {
        var score = 100
        if (usageHours > 5) score -= 10
        if (usageHours > 10) score -= 15
        // Simulate some apps being "sketchy"
        if (packageName.contains("cleaner") || packageName.contains("boost")) score -= 30
        return score.coerceIn(0, 100)
    }

    private fun formatDuration(millis: Long): String {
        val hours = millis / 3600000
        val minutes = (millis % 3600000) / 60000
        return "${hours}h ${minutes}m"
    }

    // Detect high usage (> 2 hours)
    fun detectExcessiveUsage(): List<AppInfo> {
        return getInstalledApps().filter { it.usageHours > 2.0 || it.safetyScore < 80 }
    }
    
    fun calculateDeviceSafetyScore(issues: List<AppInfo>): Int {
        if (issues.isEmpty()) return 100
        val penalty = issues.sumOf { (100 - it.safetyScore) / 2 + 10 }
        return (100 - penalty).coerceIn(0, 100)
    }

    fun uninstallApp(packageName: String) {
        val intent = Intent(Intent.ACTION_DELETE).apply {
            data = Uri.parse("package:$packageName")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}