package com.emma8047.safescan.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.emma8047.safescan.AppInfo
import com.emma8047.safescan.ThreatManager

@Composable
fun AppDetailOverlay(app: AppInfo, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A))
        ) {
            Box(modifier = Modifier.padding(24.dp)) {
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }

                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = app.name,
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Normal
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    HorizontalDivider(color = Color.Gray.copy(alpha = 0.5f), thickness = 1.dp, modifier = Modifier.fillMaxWidth(0.8f))
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    DetailRow("First Run:", app.firstRun)
                    DetailRow("Last Run:", app.lastRun)
                    DetailRow("Last Run Time:", app.lastRunTime)
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    DetailRow("CPU:", app.cpuUsage)
                    DetailRow("RAM:", app.ramUsage)
                    DetailRow("Network:", app.networkUsage)
                    DetailRow("Safety Score:", "${app.safetyScore}%")
                    
                    Spacer(modifier = Modifier.height(24.dp))

                    if (ThreatManager.activeThreats.any { it.packageName == app.packageName }) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { 
                                    ThreatManager.quarantineApp(app)
                                    onDismiss()
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Quarantine", color = Color.Black)
                            }
                            Button(
                                onClick = { 
                                    ThreatManager.ignoreApp(app)
                                    onDismiss()
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Gray.copy(alpha = 0.3f)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Ignore", color = Color.White)
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
                
            }
        }
    }
}
